/**
 * GCJ JurisSearch — modulos/scraper.js
 * Compatível com server.js e banco.js
 */

'use strict';

const path  = require('path');
const https = require('https');
const fs    = require('fs');

// ── Estado (server.js monitora via /api/scraping/progresso) ──────────────────
const estado = {
  rodando:         false,
  aguardandoLogin: false,
  seguradora:      null,
  log:             [],
  ultimoResultado: null,
};

let _paginaAtual = null;

function log(msg) {
  const linha = `[${new Date().toLocaleTimeString('pt-BR')}] ${msg}`;
  console.log(linha);
  estado.log.push(linha);
  if (estado.log.length > 200) estado.log.shift();
}

// ── Configuração ──────────────────────────────────────────────────────────────
const TOKEN_FILE    = path.join(__dirname, '..', 'dados', 'auth_token.json');
const API_BASE      = 'https://portaldeservicos.pdpj.jus.br/api/v2';
const PORTAL_URL    = 'https://portaldeservicos.pdpj.jus.br';
const TOKEN_TTL_MS  = 55 * 60 * 1000;
const LOGIN_TIMEOUT =  8 * 60 * 1000;
const DATA_MINIMA   = '2026-01-01';

const CLASSES_ACEITAS = [
  'Procedimento Comum',
  'Procedimento Comum Cível',
  'Juizado Especial',
  'Juizado Especial Cível',
];

// Mapa de código CNJ → sigla do tribunal
// Formato do número: NNNNNNN-DD.AAAA.J.TT.OOOO
const TRIBUNAL_MAP = {
  '02': 'TJAC', '03': 'TJAL', '04': 'TJAP', '05': 'TJAM',
  '06': 'TJBA', '07': 'TJCE', '08': 'TJDF', '09': 'TJES',
  '10': 'TJGO', '11': 'TJMA', '12': 'TJMT', '13': 'TJMS',
  '14': 'TJMG', '15': 'TJPA', '16': 'TJPB', '17': 'TJPR',
  '18': 'TJPE', '19': 'TJPI', '20': 'TJRJ', '21': 'TJRN',
  '22': 'TJRS', '23': 'TJRO', '24': 'TJRR', '25': 'TJSC',
  '26': 'TJSP', '27': 'TJSE', '28': 'TJTO',
};

function extrairTribunal(numeroProcesso) {
  // Padrão: 0000000-00.0000.8.TT.0000
  const match = (numeroProcesso || '').match(/\d{7}-\d{2}\.\d{4}\.\d\.(\d{2})\.\d{4}/);
  if (match) return TRIBUNAL_MAP[match[1]] || `TJ${match[1]}`;
  return '';
}

function carregarSeguradoras() {
  try {
    const regras = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'regras.json'), 'utf8'));
    if (Array.isArray(regras.seguradoras) && regras.seguradoras.length) return regras.seguradoras;
  } catch {}
  return [
    { id: 's1', nome: 'Porto Seguro Cia. de Seguros Gerais', cnpjRaw: '61198164000160' },
    { id: 's2', nome: 'Porto Seguro S.A.',                   cnpjRaw: '02149205000169' },
    { id: 's3', nome: 'HDI Global Seguros S.A.',              cnpjRaw: '18096627000153' },
    { id: 's4', nome: 'Azul Cia. de Seguros Gerais',          cnpjRaw: '33448150000111' },
    { id: 's5', nome: 'Liberty Seguros / Yelum',              cnpjRaw: '61550141000172' },
    { id: 's6', nome: 'Zurich Brasil Cia. de Seguros',        cnpjRaw: '96348677000194' },
  ];
}

// ── Token ─────────────────────────────────────────────────────────────────────
function carregarToken() {
  try {
    if (!fs.existsSync(TOKEN_FILE)) return null;
    const data = JSON.parse(fs.readFileSync(TOKEN_FILE, 'utf8'));
    if (!data.token || !data.expiresAt) return null;
    if (Date.now() >= data.expiresAt) { log('Token expirado.'); return null; }
    log(`Token válido (~${Math.round((data.expiresAt - Date.now()) / 60000)} min restantes).`);
    return data;
  } catch { return null; }
}

function salvarToken(token, cookies) {
  const data = { token, cookies, capturedAt: new Date().toISOString(), expiresAt: Date.now() + TOKEN_TTL_MS };
  const dir = path.dirname(TOKEN_FILE);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(TOKEN_FILE, JSON.stringify(data, null, 2));
  log('Token salvo em auth_token.json.');
  return data;
}

function invalidarToken() {
  try { if (fs.existsSync(TOKEN_FILE)) fs.unlinkSync(TOKEN_FILE); } catch {}
}

// ── Chrome ────────────────────────────────────────────────────────────────────
function detectarChrome() {
  const candidatos = [
    'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
    process.env.LOCALAPPDATA
      ? path.join(process.env.LOCALAPPDATA, 'Google\\Chrome\\Application\\chrome.exe')
      : null,
  ].filter(Boolean);
  for (const p of candidatos) { try { if (fs.existsSync(p)) return p; } catch {} }
  return null;
}

// ── Captura de token via CDP + automação do formulário ───────────────────────
//
// FLUXO:
// 1. Abre o Chrome — usuário faz login normalmente
// 2. A cada 2s verifica se o login foi concluído (detecta nome na tela)
// 3. Quando logado, navega para /consulta e automatiza o formulário:
//    - Muda dropdown para "CNPJ da Parte"
//    - Preenche o CNPJ da primeira seguradora
//    - Clica em Buscar
// 4. O Angular faz a chamada à API com Bearer token → CDP captura
// 5. Chrome fecha, todas as buscas seguintes vão via HTTPS direto

async function acionarBuscaParaCapturarToken(page) {
  try {
    // Navega para a consulta se não estiver lá
    if (!page.url().includes('/consulta')) {
      log('Navegando para a página de consulta...');
      await page.goto('https://portaldeservicos.pdpj.jus.br/consulta', {
        waitUntil: 'networkidle0', timeout: 20000,
      });
    }
    await sleep(3000); // aguarda Angular renderizar

    // 1. Clica no mat-select "Pesquisar por" para abrir o dropdown
    const matSelect = await page.$('mat-select');
    if (matSelect) {
      await matSelect.click();
      await sleep(1200);

      // 2. Seleciona a opção "CNPJ da Parte"
      const opts = await page.$$('mat-option');
      let selecionou = false;
      for (const opt of opts) {
        const txt = await opt.evaluate(el => el.textContent || '');
        if (txt.toLowerCase().includes('cnpj')) {
          await opt.click();
          log('Dropdown alterado para "CNPJ da Parte".');
          selecionou = true;
          break;
        }
      }
      if (!selecionou) {
        // Tenta via evaluate como fallback
        await page.evaluate(() => {
          const opts = [...document.querySelectorAll('mat-option, .mat-option')];
          const opt  = opts.find(o => o.textContent.toLowerCase().includes('cnpj'));
          if (opt) opt.click();
        });
      }
      await sleep(1000);
    }

    // 3. Preenche o campo de CNPJ
    const cnpjTeste = '61198164000160'; // Porto Seguro — só para disparar a chamada
    const input = await page.$('input[placeholder*="CNPJ"], input[placeholder*="cnpj"], input[placeholder*="000"]');
    if (input) {
      await input.click({ clickCount: 3 });
      await input.type(cnpjTeste);
      log('CNPJ preenchido.');
    } else {
      // Fallback: preenche qualquer input visível
      await page.evaluate((cnpj) => {
        const inp = [...document.querySelectorAll('input')]
          .find(i => i.offsetParent !== null && !i.readOnly);
        if (inp) { inp.value = cnpj; inp.dispatchEvent(new Event('input', { bubbles: true })); }
      }, cnpjTeste);
    }
    await sleep(600);

    // 4. Clica em Buscar
    const clicou = await page.evaluate(() => {
      const btn = [...document.querySelectorAll('button')]
        .find(b => (b.textContent || '').toLowerCase().includes('buscar'));
      if (btn) { btn.click(); return true; }
      return false;
    });
    if (clicou) {
      log('Botão "Buscar" clicado. Aguardando resposta da API...');
    } else {
      log('Aviso: botão "Buscar" não encontrado — tente clicar manualmente.');
    }

  } catch (e) {
    log(`Aviso na automação: ${e.message}. Tente buscar manualmente no portal.`);
  }
}

async function capturarToken() {
  log('Abrindo navegador. Faça login no portal jus.br com seu certificado...');
  estado.aguardandoLogin = true;

  let puppeteer;
  try { puppeteer = require('puppeteer'); } catch { puppeteer = require('puppeteer-core'); }

  const launchOptions = {
    headless: false,
    defaultViewport: null,
    args: ['--no-sandbox', '--disable-setuid-sandbox', '--start-maximized'],
  };
  const chromePath = detectarChrome();
  if (chromePath) launchOptions.executablePath = chromePath;

  const browser = await puppeteer.launch(launchOptions);

  return new Promise(async (resolve, reject) => {
    let capturado    = false;
    let autoIniciada = false;
    const page = await browser.newPage();
    _paginaAtual = page;

    // ── CDP: escuta todas as requisições de rede ──────────────────────────
    const client = await page.target().createCDPSession();
    await client.send('Network.enable');

    client.on('Network.requestWillBeSent', async (event) => {
      if (capturado) return;
      if (!event.request.url.includes('portaldeservicos.pdpj.jus.br/api')) return;
      const auth = event.request.headers['Authorization'] || event.request.headers['authorization'];
      if (!auth || !auth.startsWith('Bearer ')) return;

      capturado = true;
      clearInterval(loginPoller);
      estado.aguardandoLogin = false;
      const token = auth.replace('Bearer ', '').trim();
      let cookieStr = '';
      try { cookieStr = (await page.cookies()).map(c => `${c.name}=${c.value}`).join('; '); } catch {}

      log('Token capturado com sucesso! Fechando navegador...');
      _paginaAtual = null;
      try { await browser.close(); } catch {}
      resolve(salvarToken(token, cookieStr));
    });

    // ── Poller: detecta login pela URL (Angular não expõe innerText) ─────────
    // Login concluído = URL NÃO contém sso/login/auth/keycloak
    const loginPoller = setInterval(async () => {
      if (capturado || autoIniciada) return;
      try {
        const url = page.url();
        const naTelaDeLogin = url.includes('sso') || url.includes('/login')
                           || url.includes('auth') || url.includes('keycloak')
                           || url === 'about:blank' || url === PORTAL_URL
                           || url === PORTAL_URL + '/';

        if (!naTelaDeLogin && url.includes('portaldeservicos.pdpj.jus.br')) {
          autoIniciada = true;
          log('Login detectado pela URL! Iniciando automação do formulário...');
          await sleep(2000); // aguarda Angular estabilizar
          await acionarBuscaParaCapturarToken(page);
        }
      } catch (e) { /* página em transição */ }
    }, 2000);

    const timeout = setTimeout(async () => {
      if (capturado) return;
      clearInterval(loginPoller);
      estado.aguardandoLogin = false;
      _paginaAtual = null;
      try { await browser.close(); } catch {}
      reject(new Error('Timeout: login não detectado em 8 minutos.'));
    }, LOGIN_TIMEOUT);

    browser.on('disconnected', () => {
      clearTimeout(timeout);
      clearInterval(loginPoller);
      estado.aguardandoLogin = false;
      _paginaAtual = null;
      if (!capturado) reject(new Error('Navegador fechado antes de capturar o token.'));
    });

    try { await page.goto(PORTAL_URL, { waitUntil: 'domcontentloaded', timeout: 30000 }); } catch {}
  });
}

// ── Chamadas diretas à API ────────────────────────────────────────────────────
function apiGet(url, tokenData) {
  return new Promise((resolve, reject) => {
    const req = https.get(url, {
      headers: {
        'Authorization': `Bearer ${tokenData.token}`,
        'Accept': 'application/json',
        ...(tokenData.cookies ? { 'Cookie': tokenData.cookies } : {}),
      },
    }, (res) => {
      if (res.statusCode === 401 || res.statusCode === 403) return reject(new Error('TOKEN_EXPIRADO'));
      if (res.statusCode !== 200) return reject(new Error(`HTTP ${res.statusCode}`));
      let body = '';
      res.on('data', c => body += c);
      res.on('end', () => {
        try { resolve(JSON.parse(body)); }
        catch { reject(new Error('JSON inválido: ' + body.slice(0, 200))); }
      });
    });
    req.on('error', reject);
    req.setTimeout(30000, () => { req.destroy(); reject(new Error('Timeout na API')); });
  });
}

async function buscarPorCNPJ(cnpj, tokenData) {
  const todos = [];
  let pagina = 0, totalPaginas = 1;
  while (pagina < totalPaginas) {
    const url = `${API_BASE}/processos?cpfCnpjParte=${cnpj}&page=${pagina}&size=20`;
    log(`  Página ${pagina + 1} de ${totalPaginas}...`);
    const dados = await apiGet(url, tokenData);
    if (Array.isArray(dados.content)) {
      todos.push(...dados.content);
      totalPaginas = dados.totalPages || 1;
    } else break;
    pagina++;
    if (pagina < totalPaginas) await sleep(500);
  }
  return todos;
}

// ── Filtros e normalização ────────────────────────────────────────────────────
function deveIncluir(proc, cnpjSeg, dtIni, dtFim) {
  const data = proc.dataAjuizamento || '';
  if (data < (dtIni || DATA_MINIMA)) return false;
  if (dtFim && data > dtFim) return false;
  const classe = (proc.classeProcessual && proc.classeProcessual.nome
    ? proc.classeProcessual.nome
    : proc.classeProcessual || '').trim();
  if (!CLASSES_ACEITAS.some(c => classe.toLowerCase().includes(c.toLowerCase()))) return false;
  return (proc.partes || []).some(parte => {
    if ((parte.cpfCnpj || '').replace(/\D/g, '') === cnpjSeg) return false;
    return (parte.advogados || []).length === 0;
  });
}

// ATENÇÃO: campo principal é "numero" — assim banco.js encontra por p.numero
function normalizar(proc, seg) {
  const partes   = proc.partes || [];
  const parteSeg = partes.find(x => (x.cpfCnpj || '').replace(/\D/g, '') === seg.cnpjRaw);
  const semAdv   = partes
    .filter(x => (x.cpfCnpj || '').replace(/\D/g, '') !== seg.cnpjRaw && (x.advogados || []).length === 0)
    .map(x => ({ nome: x.nome, polo: x.tipoPolo, cpfCnpj: x.cpfCnpj }));

  return {
    numero:              proc.numeroProcesso,           // ← chave usada pelo banco.js
    seguradora_id:       seg.id,
    seguradora_nome:     seg.nome,
    polo_seguradora:     (parteSeg && parteSeg.tipoPolo) || '',
    tribunal:            extrairTribunal(proc.numeroProcesso), // ← filtro do banco.js
    classe:              (proc.classeProcessual && proc.classeProcessual.nome) || proc.classeProcessual || '',
    assuntos:            (proc.assuntos || []).map(a => a.nome || a).join(', '),
    orgao:               (proc.orgaoJulgador && proc.orgaoJulgador.nome) || proc.orgaoJulgador || '',
    valor_causa:         proc.valorCausa || 0,
    data_ajuizamento:    proc.dataAjuizamento || '',
    partes_sem_advogado: semAdv,
    dados_completos:     proc,
    atualizado_em:       new Date().toISOString(),
    status:              'novo',
  };
}

// ── Função principal ──────────────────────────────────────────────────────────
async function executarScraping({ completa = false, dtIni, dtFim } = {}) {
  if (estado.rodando) return;
  estado.rodando = true;
  estado.log = [];
  estado.ultimoResultado = null;

  try {
    log('Busca iniciada.');
    const banco = require('./banco');

    // 1. Token
    let tokenData = carregarToken();
    if (!tokenData) {
      log('Sem token válido. Aguardando login no navegador...');
      tokenData = await capturarToken();
    }

    // 2. Loop por seguradoras
    const seguradoras = carregarSeguradoras();
    let totalNovos = 0, totalApi = 0;
    let tokenExpirou = false;

    for (const seg of seguradoras) {
      estado.seguradora = seg.nome;
      log(`\nBuscando: ${seg.nome}`);

      let brutos;
      try {
        brutos = await buscarPorCNPJ(seg.cnpjRaw, tokenData);
      } catch (err) {
        if (err.message === 'TOKEN_EXPIRADO') {
          log('Token expirado. Inicie a busca novamente para reautenticar.');
          invalidarToken();
          tokenExpirou = true;
          break;
        }
        log(`Erro em "${seg.nome}": ${err.message}`);
        continue;
      }

      log(`Retornados pela API: ${brutos.length}`);
      totalApi += brutos.length;

      // ── DEBUG: mostra estrutura real do primeiro processo ───────────────
      if (brutos.length > 0) {
        const amostra = brutos[0];
        // Mostra as chaves do objeto e os primeiros 800 chars do JSON
        log(`  DEBUG chaves: ${Object.keys(amostra).join(', ')}`);
        log(`  DEBUG JSON: ${JSON.stringify(amostra).substring(0, 800)}`);
      }
      // ── FIM DEBUG ────────────────────────────────────────────────────────

      const filtrados = brutos.filter(p => deveIncluir(p, seg.cnpjRaw, dtIni, dtFim));
      log(`Após filtros de negócio: ${filtrados.length}`);

      if (filtrados.length > 0) {
        // banco.salvarProcessos() recebe um array e retorna quantidade de novos
        const novos = banco.salvarProcessos(filtrados.map(p => normalizar(p, seg)));
        log(`Salvos como novos: ${novos}`);
        totalNovos += novos;
      }

      await sleep(800);
    }

    // 3. Marca a última busca no banco
    if (!tokenExpirou) {
      banco.marcarUltimaBusca(completa ? 'completa' : 'diaria');
    }

    estado.ultimoResultado = { novos: totalNovos, total: totalApi, em: new Date().toISOString() };
    log(`\nConcluído. ${totalNovos} novo(s) processo(s) de ${totalApi} analisados.`);

  } catch (err) {
    log(`Erro fatal: ${err.message}`);
    estado.ultimoResultado = { erro: err.message };
  } finally {
    estado.rodando    = false;
    estado.seguradora = null;
  }
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

// ── Exports (interface esperada pelo server.js) ───────────────────────────────
module.exports = {
  estado,
  executarScraping,
  get paginaAtual() { return _paginaAtual; },
};
